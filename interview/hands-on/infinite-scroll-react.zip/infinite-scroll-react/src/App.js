import React from "react";
import { Home } from "pages";
import { BoundaryProvider } from "contexts";

export default () => {
  return (
    <div className="main">
      <Home />
    </div>
  );
};
